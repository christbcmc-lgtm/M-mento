'use strict';
// K22 (X3, X4, X5, X8, X9, X10) — Honnêteté et cohérence des pages publiques.
//
//   X3 : pages publiques en palette fixe « bleu nuit », SANS sélecteur de
//        thème ni script de thème ; l'accueil ne vante plus « 8 thèmes ».
//   X4 : « Essayer gratuitement » pointe vers demande.html?type=essai, et la
//        case « Essai gratuit » y est présélectionnée (code exécuté).
//   X5 : acces.html propose « Lien perdu ? » (récupération de code) et un
//        écran de succès avec le lien en lecture seule + Copier + Ouvrir +
//        phrase sur les favoris (code exécuté).
//   X8 : decision.html affiche les matières demandées (code exécuté).
//   X9 : vouvoiement — plus de « Tes cours » / « Tu obtiens ».
//   X10: demande.html — numéro international (+229) marqué obligatoire.
//
// Les tests de comportement EXÉCUTENT réellement le JS de la page dans jsdom.

const test = require('node:test');
const assert = require('node:assert');
const fs = require('node:fs');
const path = require('node:path');
const { JSDOM } = require('jsdom');

const PUB = path.join(__dirname, '..', 'public');
const PUBLIQUES = ['index.html', 'acces.html', 'demande.html', 'essai.html', 'decision.html'];

function lire(f) { return fs.readFileSync(path.join(PUB, f), 'utf8'); }
function lireJs(f) { return fs.readFileSync(path.join(PUB, 'assets', f), 'utf8'); }

function tick(n) {
  n = n || 6;
  let p = Promise.resolve();
  for (let i = 0; i < n; i++) p = p.then(() => new Promise((r) => setTimeout(r, 0)));
  return p;
}

// ---------------------------------------------------------------------------
// X3 — palette fixe bleu nuit, pas de sélecteur ni de script de thème.
// ---------------------------------------------------------------------------

test('K22a : chaque page publique force data-theme="bleu-nuit" sur <html>', () => {
  PUBLIQUES.forEach((f) => {
    const dom = new JSDOM(lire(f));
    const t = dom.window.document.documentElement.getAttribute('data-theme');
    assert.strictEqual(t, 'bleu-nuit', f + ' doit être en bleu nuit, reçu : ' + t);
  });
});

test('K22b : aucune page publique ne contient de sélecteur de thème', () => {
  PUBLIQUES.forEach((f) => {
    const dom = new JSDOM(lire(f));
    const sel = dom.window.document.querySelector('select.theme');
    assert.strictEqual(sel, null, f + ' ne doit plus avoir de <select class="theme">');
  });
});

test('K22c : aucune page publique ne charge theme-boot.js ni app-theme.js', () => {
  PUBLIQUES.forEach((f) => {
    const html = lire(f);
    assert.ok(!/theme-boot\.js/.test(html), f + ' ne doit plus charger theme-boot.js');
    assert.ok(!/app-theme\.js/.test(html), f + ' ne doit plus charger app-theme.js');
  });
});

test('K22d : l’accueil ne vante plus « 8 thèmes d’affichage »', () => {
  const html = lire('index.html');
  assert.ok(!/8\s*thèmes/i.test(html), 'le badge « 8 thèmes » doit disparaître');
});

// ---------------------------------------------------------------------------
// X4 — « Essayer gratuitement » -> demande.html?type=essai + présélection.
// ---------------------------------------------------------------------------

test('K22e : le bouton « Essayer gratuitement » mène à demande.html?type=essai', () => {
  const dom = new JSDOM(lire('index.html'));
  const a = Array.prototype.find.call(
    dom.window.document.querySelectorAll('a'),
    (x) => /Essayer gratuitement/i.test(x.textContent)
  );
  assert.ok(a, 'le lien existe');
  assert.ok(/demande\.html\?type=essai/.test(a.getAttribute('href')),
    'href attendu demande.html?type=essai, reçu : ' + a.getAttribute('href'));
  assert.ok(!/essai\.html/.test(a.getAttribute('href')),
    'ne doit plus pointer vers essai.html (page sans invitation = erreur)');
});

test('K22f : demande.html?type=essai présélectionne la case « Essai gratuit » (JS exécuté)', async () => {
  const dom = new JSDOM(lire('demande.html'), { url: 'https://memento.test/demande.html?type=essai', runScripts: 'outside-only' });
  const win = dom.window;
  win.fetch = function () { return Promise.resolve({ ok: true, json() { return Promise.resolve({ ok: true, matieres: [{ id: 'thermo', titre: 'Thermodynamique' }] }); } }); };
  win.eval(lireJs('demande.js'));
  win.document.dispatchEvent(new win.Event('DOMContentLoaded'));
  await tick();
  const essai = win.document.querySelector('input[name="type"][value="essai"]');
  const abo = win.document.querySelector('input[name="type"][value="abonnement"]');
  assert.ok(essai.checked, 'la case essai doit être cochée');
  assert.ok(!abo.checked, 'la case abonnement ne doit plus être cochée');
});

// ---------------------------------------------------------------------------
// X10 — demande.html : numéro international (+229) marqué obligatoire.
// ---------------------------------------------------------------------------

test('K22g : le champ numéro de demande.html est obligatoire et au format +229', () => {
  const dom = new JSDOM(lire('demande.html'));
  const num = dom.window.document.getElementById('d-num');
  assert.ok(num, '#d-num existe');
  assert.ok(num.hasAttribute('required'), '#d-num doit être required');
  assert.ok(/\+229/.test(num.getAttribute('placeholder') || ''),
    'placeholder international +229 attendu, reçu : ' + num.getAttribute('placeholder'));
  // Le mot « obligatoire » figure sur le libellé.
  const lab = dom.window.document.querySelector('label[for="d-num"]');
  assert.ok(/obligatoire/i.test(lab.textContent), 'le libellé dit « obligatoire »');
});

// ---------------------------------------------------------------------------
// X5 — acces.html : « Lien perdu ? » + écran de succès copiable (JS exécuté).
// ---------------------------------------------------------------------------

function monterAcces() {
  const dom = new JSDOM(lire('acces.html'), { url: 'https://memento.test/acces.html', runScripts: 'outside-only' });
  const win = dom.window;
  const calls = [];
  win.fetch = function (url, opts) {
    let body = {};
    try { body = JSON.parse((opts && opts.body) || '{}'); } catch (e) {}
    calls.push({ url: String(url), body: body });
    let payload = { ok: true };
    if (/a=activer/.test(String(url))) payload = { ok: true, lien: 'https://memento.test/e/jeton-perso' };
    else if (/a=code-reset/.test(String(url))) payload = { ok: true, message: 'Si les informations correspondent, un nouveau code a été envoyé.' };
    return Promise.resolve({ ok: true, status: 200, json() { return Promise.resolve(payload); } });
  };
  win.eval(lireJs('access.js'));
  win.document.dispatchEvent(new win.Event('DOMContentLoaded'));
  const $ = (id) => win.document.getElementById(id);
  return { win, calls, $ };
}

test('K22h : acces.html propose un lien « Lien perdu ? » qui ouvre un formulaire de récupération', async () => {
  const env = monterAcces();
  const ouvrir = env.$('lien-perdu-ouvrir');
  assert.ok(ouvrir, 'le lien « Lien perdu ? » existe');
  assert.ok(/lien perdu/i.test(ouvrir.textContent));
  const panneau = env.$('lien-perdu');
  assert.ok(panneau.hidden, 'le formulaire est caché au départ');
  ouvrir.dispatchEvent(new env.win.Event('click'));
  assert.ok(!panneau.hidden, 'un clic révèle le formulaire de récupération');
});

test('K22i : « Lien perdu ? » appelle code-reset avec email + numéro (JS exécuté)', async () => {
  const env = monterAcces();
  env.$('lien-perdu-ouvrir').dispatchEvent(new env.win.Event('click'));
  env.$('lp-mail').value = 'membre@exemple.test';
  env.$('lp-num').value = '+229 01 02 03 04 05';
  env.$('f-perdu').dispatchEvent(new env.win.Event('submit'));
  await tick();
  const appel = env.calls.find((c) => /a=code-reset/.test(c.url));
  assert.ok(appel, 'un appel code-reset est parti');
  assert.strictEqual(appel.body.email, 'membre@exemple.test');
  assert.strictEqual(appel.body.numero, '+229 01 02 03 04 05');
});

test('K22j : écran de succès — lien en lecture seule + Copier + Ouvrir + phrase favoris (JS exécuté)', async () => {
  const env = monterAcces();
  // Les 3 éléments de l'écran de succès existent (lecture seule, copier, ouvrir).
  const url = env.$('lien-url');
  assert.ok(url && url.hasAttribute('readonly'), 'champ lien en lecture seule');
  assert.ok(env.$('lien-copier'), 'bouton Copier');
  assert.ok(env.$('lien-ouvrir'), 'bouton Ouvrir mon espace');
  assert.ok(/favoris/i.test(env.win.document.body.textContent), 'phrase sur les favoris présente');

  // On exécute l'activation : le lien renvoyé doit remplir le champ et le bouton.
  env.$('c-nom').value = 'Dupont';
  env.$('c-mail').value = 'membre@exemple.test';
  env.$('c-cle').value = 'ABCDE-ABCDE-ABCDE-ABCDE';
  env.$('f-con').dispatchEvent(new env.win.Event('submit'));
  await tick();
  assert.strictEqual(env.$('lien-url').value, 'https://memento.test/e/jeton-perso',
    'le lien personnel apparaît en lecture seule');
  assert.strictEqual(env.$('lien-ouvrir').getAttribute('href'), 'https://memento.test/e/jeton-perso',
    'le bouton Ouvrir pointe vers le lien personnel');
  assert.ok(env.$('ov').classList.contains('on'), 'l’écran de succès est affiché');
});

// ---------------------------------------------------------------------------
// X8 — decision.html affiche les matières demandées (JS exécuté).
// ---------------------------------------------------------------------------

test('K22k : decision.html affiche les matières demandées (ids -> titres)', async () => {
  const dom = new JSDOM(lire('decision.html'), { url: 'https://memento.test/decision.html?d=jeton', runScripts: 'outside-only' });
  const win = dom.window;
  win.fetch = function (url) {
    let payload = { ok: true };
    if (/a=decision/.test(String(url))) payload = { ok: true, demande: { id: 'dem1', nom: 'Dupont', prenom: 'Awa', email: 'a@b.test', type: 'abonnement', matieres: ['thermo', 'proba'], message: '' } };
    return Promise.resolve({ ok: true, status: 200, json() { return Promise.resolve(payload); } });
  };
  win.eval(lireJs('decision.js'));
  win.document.dispatchEvent(new win.Event('DOMContentLoaded'));
  await tick();
  const txt = win.document.getElementById('d-mats').textContent;
  assert.ok(/Thermodynamique/.test(txt), 'thermo -> titre lisible : ' + JSON.stringify(txt));
  assert.ok(/Probabilit/.test(txt), 'proba -> titre lisible : ' + JSON.stringify(txt));
});

// ---------------------------------------------------------------------------
// X9 — vouvoiement partout (plus de tutoiement sur accueil et acces).
// ---------------------------------------------------------------------------

test('K22l : plus de tutoiement (« Tes cours » / « Tu obtiens » / « tu reçois »)', () => {
  ['index.html', 'acces.html', 'demande.html', 'essai.html', 'decision.html'].forEach((f) => {
    const t = lire(f);
    assert.ok(!/Tes cours/.test(t), f + ' : « Tes cours » doit disparaître');
    assert.ok(!/\bTu obtiens\b/.test(t), f + ' : « Tu obtiens » doit disparaître');
    assert.ok(!/\btu reçois\b/.test(t), f + ' : « tu reçois » doit disparaître');
  });
});
