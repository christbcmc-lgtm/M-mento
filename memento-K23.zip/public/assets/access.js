/* Mémento — page d'accès (étape 1 : interface + validations de format).
   La vérification réelle (clé/lien/code) sera branchée sur le backend à l'étape 2. */
(function () {
  var CIT = [
    "Apprendre, c'est se souvenir de ce qu'on a compris.",
    "Un peu chaque jour vaut mieux que beaucoup une seule fois.",
    "La persévérance transforme le difficile en habitude."
  ];

  function $(id){ return document.getElementById(id); }

  // Onglets
  function selectTab(which){
    var con = which === 'con';
    $('t-con').setAttribute('aria-selected', con ? 'true':'false');
    $('t-dem').setAttribute('aria-selected', con ? 'false':'true');
    $('p-con').hidden = !con;
    $('p-dem').hidden = con;
  }

  function validEmail(v){ return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v); }
  function validKey(v){ return /^[A-Z0-9]{5}-[A-Z0-9]{5}-[A-Z0-9]{5}-[A-Z0-9]{5}$/.test(v); }

  document.addEventListener('DOMContentLoaded', function(){
    $('t-con').addEventListener('click', function(){ selectTab('con'); });
    $('t-dem').addEventListener('click', function(){ selectTab('dem'); });

    var cle = $('c-cle');
    if (cle) cle.addEventListener('input', function(){ cle.value = cle.value.toUpperCase(); });

    var form = $('f-con');
    if (form) form.addEventListener('submit', function(e){
      e.preventDefault();
      var err = $('c-err'); err.textContent = '';
      var nom = $('c-nom').value.trim();
      var email = $('c-mail').value.trim();
      var k = $('c-cle').value.trim();
      if (!nom) { err.textContent = 'Veuillez indiquer votre nom.'; return; }
      if (!validEmail(email)) { err.textContent = 'Adresse email invalide.'; return; }
      if (!validKey(k)) { err.textContent = 'Clé au format XXXXX-XXXXX-XXXXX-XXXXX.'; return; }
      var btn = form.querySelector('button[type="submit"]');
      btn.disabled = true; var libelle = btn.textContent; btn.textContent = 'Activation…';
      fetch('/api/auth?a=activer', {
        method: 'POST', credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'mh' },
        body: JSON.stringify({ nom: nom, email: email, cle: k })
      }).then(function(r){ return r.json().then(function(j){ return { ok: r.ok, j: j }; }); })
        .then(function(res){
          btn.disabled = false; btn.textContent = libelle;
          if (!res.ok || !res.j.ok) { err.textContent = (res.j && res.j.erreur) || 'Activation impossible.'; return; }
          $('cit').textContent = '« ' + CIT[Math.floor(Math.random()*CIT.length)] + ' »';
          if (res.j.lien) {
            var inp = $('lien-url');
            if (inp) inp.value = res.j.lien;
            var open = $('lien-ouvrir');
            if (open) open.href = res.j.lien;
          }
          $('ov').classList.add('on');
        })
        .catch(function(){ btn.disabled = false; btn.textContent = libelle; err.textContent = 'Réseau indisponible, réessayez.'; });
    });

    var ok = $('ov-ok');
    if (ok) ok.addEventListener('click', function(){ $('ov').classList.remove('on'); });

    // Copie du lien personnel dans le presse-papier (avec repli execCommand).
    var copier = $('lien-copier');
    if (copier) copier.addEventListener('click', function(){
      var inp = $('lien-url');
      if (!inp) return;
      try { inp.focus(); inp.select(); inp.setSelectionRange(0, 99999); } catch (e) {}
      var done = function(){ var t = copier.textContent; copier.textContent = 'Copié ✔'; setTimeout(function(){ copier.textContent = t; }, 1500); };
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(inp.value).then(done, function(){ try { document.execCommand('copy'); } catch (e) {} done(); });
      } else { try { document.execCommand('copy'); } catch (e) {} done(); }
    });

    // X5 : « Lien perdu ? » — récupération du code (email + numéro) via code-reset.
    var ouvrirPerdu = $('lien-perdu-ouvrir');
    if (ouvrirPerdu) ouvrirPerdu.addEventListener('click', function(e){
      e.preventDefault();
      var p = $('lien-perdu');
      if (p) p.hidden = !p.hidden;
    });
    var fp = $('f-perdu');
    if (fp) fp.addEventListener('submit', function(e){
      e.preventDefault();
      var err = $('lp-err'); err.textContent = '';
      var okm = $('lp-ok'); okm.hidden = true; okm.textContent = '';
      var email = $('lp-mail').value.trim();
      var numero = $('lp-num').value.trim();
      if (!validEmail(email)) { err.textContent = 'Adresse email invalide.'; return; }
      if (!numero) { err.textContent = 'Numéro de téléphone requis.'; return; }
      var btn = fp.querySelector('button[type="submit"]');
      btn.disabled = true; var lib = btn.textContent; btn.textContent = 'Envoi…';
      fetch('/api/public?a=code-reset', {
        method: 'POST', credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'mh' },
        body: JSON.stringify({ email: email, numero: numero })
      }).then(function(r){ return r.json().then(function(j){ return { ok: r.ok, j: j }; }); })
        .then(function(res){
          btn.disabled = false; btn.textContent = lib;
          okm.hidden = false;
          okm.textContent = (res.j && res.j.message) || 'Si les informations correspondent, un nouveau code a été envoyé.';
          fp.reset();
        })
        .catch(function(){ btn.disabled = false; btn.textContent = lib; err.textContent = 'Réseau indisponible, réessayez.'; });
    });
  });
})();
