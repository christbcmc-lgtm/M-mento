# RAPPORT_K19 — X1 : fiche d'activation, matières lues depuis le catalogue réel

> Format : (a) fait · (b) preuves · (c) reste · (d) risques · (e) gestes 📱.
> Étiquetage : **[fait-vérifié]** test à l'appui · **[non-vérifié]** sans navigateur · **[hypothèse]**.
> Élément : **K19 (X1, bloquant)** — SPECS-RESTANTES §3.1.

## (a) Ce qui est fait

**Constat corrigé (X1).** `list_matieres` (`api/admin.js`) lisait la collection
Firestore `matieres` (vide) → la fiche d'activation affichait « Aucune matière
déclarée dans le catalogue » et l'admin ne pouvait **pas** choisir les matières.
Désormais elle lit `contenu/catalogue.json` via une fonction de catalogue
partagée, renvoie `{ id, nom: titre, ordre, bientot }`, et la liste n'est jamais
vide quand Firestore l'est.

Modifications :

1. **`contenu/catalogue.json`** — ajout de `ordre` (1, 2, 3) sur chaque matière
   et de `bientot: true` sur `info` (Informatique).
2. **`api/_lib/contenu.js`** — nouvelle fonction partagée `catalogueListe()` :
   lit le catalogue disque, renvoie un tableau `[{ id, nom, ordre, bientot }]`
   trié par `ordre`, sans aucun accès Firestore (donc jamais vide à cause d'une
   collection vide). Exportée.
3. **`api/admin.js`** — l'action `list_matieres` appelle `catalogueListe()` au
   lieu de `base.collection('matieres').orderBy('ordre').get()`.
4. **`public/assets/admin-client.js`** (`rendreChips`) — une matière `bientot`
   est **affichée mais non cochable** : classe `chip bientot`, suffixe
   « (bientôt) », `aria-disabled="true"`, aucun gestionnaire de clic (donc elle
   n'entre jamais dans la sélection envoyée à `approuver_nm`).
5. **`public/assets/espace.css`** — style `.chip.bientot` (atténué, curseur
   `not-allowed`).

Le message « Cochez au moins une matière. » (fonction `accorder`) est inchangé et
reste la garde « au moins une matière » exigée par la spécification.

## (b) Preuves — **[fait-vérifié]**

Nouveau fichier `test/k19.test.js`, 7 cas `test()`, protocole rouge-avant / vert-après :

- **K19a** : la liste n'est jamais vide (reconstitution de l'ancienne lecture
  Firestore vide → `[]` ; `catalogueListe()` → ≥ 3 matières).
- **K19b** : chaque entrée porte `{ id, nom, ordre, bientot }` (types vérifiés),
  tri par `ordre` croissant, `nom` = titre lisible (« Thermodynamique »).
- **K19c** : `info.bientot === true` ; `thermo` et `proba` cochables.
- **K19d** (jsdom, exécute le code) : après connexion admin, une case `.chip`
  par matière apparaît (3), contre zéro avant (span « Aucune matière »).
- **K19e** (jsdom) : clic sur la puce Thermodynamique → classe `on` ; clic sur
  « Accorder » → `approuver_nm` reçoit `matieres: ['thermo']` et le bon `demandeId`.
- **K19f** (jsdom) : la puce « bientôt » (Informatique) est visible, porte
  `aria-disabled`, ne se coche pas au clic, et seule ne permet pas d'approuver.
- **K19g** (jsdom) : sans aucune case cochée, `#g-err` affiche « Cochez au moins
  une matière. » et aucun appel `approuver_nm` n'est émis.

Sortie de la suite complète (`node --test`) après K19 :

```
# tests 26
# pass  26
# fail  0
# cancelled 0 / skipped 0 / todo 0
```

### Note sur le compteur `# tests` (base de comparaison 154)

L'environnement d'exécution ne dispose que de **Node 16.20.2** (et Node 12),
aucun Node ≥ 18. Sous Node 16, `node --test` compte les **fichiers** de test
(sous-tests de 1er niveau), pas les cas `test()` individuels : il ne peut donc
structurellement pas afficher 154 (chiffre obtenu par l'auteur sous Node ≥ 18,
qui aplatit tous les `test()`). Décompte réel mesuré ici : **26** unités de
1er niveau (25 fichiers `*.test.js` + le helper `test/fake-db.js` ramassé par
l'auto-découverte), **0 échec**, et **168** `test()` de 1er niveau définis
(161 à l'état K1ter + 7 ajoutés par K19). Le « < 154 » est un artefact de
version de Node, pas une base tronquée : 0 fail, toute la base s'exécute.

## (c) Ce qui reste

- K20 (X2, K1quater), K21 (X6/X7), K22 (X3/X4/X5/X8/X9/X10), K23 (X11), puis
  K11, K10, K4, K5, K6, K12→K16, K18 (ordre SPECS §3).

## (d) Risques / écarts connus

- `proba` n'a pas encore de contenu sur disque ; elle reste **cochable** (le
  SPECS ne demande `bientot` que pour `info`). Si le propriétaire veut aussi
  marquer `proba` « bientôt », ajouter `"bientot": true` à son entrée du
  catalogue — aucun autre changement de code. **[hypothèse]** sur l'intention.
- La collection Firestore `matieres` n'est plus lue par `list_matieres` ; aucun
  autre appelant de cette collection côté serveur (vérifié par recherche). Si des
  règles ou outils externes y écrivaient, ils deviennent sans effet sur la fiche.

## (e) Gestes 📱 à faire par le propriétaire (après déploiement)

1. Ouvrir la console admin, aller à « Accorder / activer un accès » : vérifier que
   **trois** cases apparaissent (Thermodynamique, Probabilités et statistiques,
   Informatique) ; « Informatique » doit être grisée et marquée « (bientôt) »,
   non cliquable.
2. Cocher Thermodynamique, préparer une demande, valider : l'activation doit
   partir avec cette matière. Sans aucune case : le message « Cochez au moins
   une matière. » doit s'afficher. **[non-vérifié]** sans navigateur réel.
