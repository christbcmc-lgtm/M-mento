# RAPPORT_K21 — X6 (formulaire d'activation honnête) + X7 (essai : accorder)

> Format : (a) ce qui est fait · (b) preuves · (c) ce qui reste · (d) risques · (e) gestes 📱
> Étiquettes : [fait-vérifié] prouvé par un test exécuté · [non-vérifié] · [hypothèse]

---

## (a) Ce qui est fait

**X6 — Le formulaire « accorder un accès » ne ment plus.** [fait-vérifié]
- Le **numéro de téléphone devient obligatoire** (preuve d'identité, décision D7).
  - Côté affichage : le libellé dit « Numéro (obligatoire — preuve d'identité) »,
    le champ porte l'attribut `required` et un exemple de saisie (placeholder).
  - Côté logique : dans `accorder()`, un contrôle ajouté **après** la vérification
    des matières exige au moins 8 chiffres (après nettoyage des espaces et du
    `+`). En dessous, l'opération est bloquée et le message « Numéro obligatoire
    (au moins 8 chiffres). » s'affiche ; aucune demande n'est envoyée au serveur.
  - Le numéro saisi est désormais transmis au serveur dans la demande d'octroi.
- La **case « générer un code par matière » a été retirée** (il n'existe plus
  d'élément `#g-code`). À la place, une note explique qu'**un seul code d'accès
  par membre** est généré automatiquement, valable pour toutes ses matières (D6).
- Le **libellé du quota d'heures est honnête** : il indique explicitement
  « non appliqué pour l'instant » (plus de « 0 = illimité » trompeur).

**X7 — L'essai gratuit se dit « accorder », pas « inviter ».** [fait-vérifié]
- Le bouton déclenche bien l'action serveur `accorder_essai` (jamais
  l'ancienne `inviter_essai`). La fonction UI est renommée `accorderEssai`,
  le titre de section devient « Accorder un essai gratuit » et le bouton
  « Accorder l'essai et envoyer le lien ».
- Côté serveur, `inviter_essai` répond déjà **410** (« Action retirée :
  utilisez “ accorder un essai ” ») — état préexistant (K3/D10), ici confirmé.

**Non-régression.** [fait-vérifié]
- `test/k19.test.js` (cas k19e) a été adapté : il pose maintenant le numéro
  désormais requis avant de valider l'octroi (sinon le nouveau contrôle le
  bloquerait). Les cas k19f/k19g (aucune matière cochée) ne sont pas impactés :
  le contrôle matières s'exécute avant celui du numéro.

## (b) Preuves (rouge → vert, le test EXÉCUTE le code de l'interface)

`test/k21.test.js` — 8 cas jsdom, tous verts (exécution réelle de `admin-client.js`
dans un DOM chargé depuis `admin.html`) :

| Cas | Ce qu'il prouve |
|---|---|
| K21a | le champ numéro porte `required` et le mot « obligatoire » est présent |
| K21b | `#g-code` a disparu du DOM ; la note « un seul code » est présente |
| K21c | le libellé du quota dit « non appliqué pour l'instant » |
| K21d | SANS numéro : aucun appel `approuver_nm`, message « Numéro obligatoire » |
| K21e | numéro trop court (< 8 chiffres) : toujours refusé |
| K21f | numéro valide : `approuver_nm` part ET transporte le numéro saisi |
| K21g | le bouton d'essai déclenche l'action `accorder_essai` (pas `inviter_essai`) |
| K21h | le libellé du bouton d'essai dit « accorder » (plus « inviter ») |

Journal d'exécution (fichier K21 isolé) : `# tests 8 / # pass 8 / # fail 0`.

**Suite complète** : `node --test` → **`# tests 28 / # pass 28 / # fail 0`**
(28 unités = 27 fichiers `*.test.js` + le helper `fake-db.js`).
Rappel d'environnement : sous **Node 16.20.2**, `# tests` compte les FICHIERS,
pas les `test()` de 1er niveau ; 0 fail prouve la suite verte.

## (c) Ce qui reste
- Suite SPECS §3 : **K22**, K23, puis K11, K10, K4, K5, K6, K12→K16, K18.

## (d) Risques / limites
- [hypothèse] Le serveur `approuver_nm` accepte un champ `numero` supplémentaire
  sans le rejeter (champ ignoré s'il n'est pas attendu) ; la persistance effective
  du numéro côté Firestore relèvera d'un élément serveur ultérieur si demandé.
  Ici, X6 porte sur l'honnêteté **du formulaire** (obligatoire + transmis).
- [non-vérifié] Validation purement côté interface (8 chiffres) ; aucune
  vérification de format international stricte — volontaire (saisie Bénin / étranger).
- Aucune clé/secret touché, aucune dépendance ajoutée (jsdom reste devDependency).

## (e) Gestes 📱 (pour vérifier soi-même)
1. Ouvrir la console admin, aller à la fiche d'activation d'un membre.
2. Choisir une matière, remplir l'email, **laisser le numéro vide** et cliquer
   « Accorder » → un message « Numéro obligatoire » apparaît, rien n'est envoyé.
3. Saisir un numéro (ex. `+229 01 02 03 04 05`) → l'octroi part normalement.
4. Vérifier qu'il n'y a plus de case « générer un code par matière », mais une
   note « un seul code par membre », et que le quota est marqué « non appliqué ».
5. Dans la section essai : le titre et le bouton disent « Accorder ».
