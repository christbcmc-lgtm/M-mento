# PROGRESS.md — point de reprise (grande partie K1→K18)

> Fichier de reprise unique (QUALITE-MATIERE §9.3). Une autre IA doit pouvoir
> continuer à partir de ce seul fichier. Mis à jour après chaque élément.
> Dernière mise à jour : 2026-10-31 (après K23).

## Base de travail
- Dossier de travail courant (extrait de `memento-K21-K17.zip`, deps réinstallées ; K17 réintégré).
- Specs déposées : `docs/GUIDE-EXECUTION.md` (version complète) + `docs/SPECS-RESTANTES.md`.
- Suite de tests : `node --test` — **30 unités (29 fichiers `*.test.js` + helper `fake-db.js`), 30 pass, 0 fail**.
- `node_modules` installé (exclu des zip). `jsdom` installé (devDependency, test seul).
- Runtime : **Node 16.20.2** uniquement (pas de Node ≥ 18). `# tests` compte les FICHIERS, pas les `test()` : le « 154 » de la base de comparaison n'est pas affichable ici (artefact de version). Base prouvée complète : 0 fail.

## ✅ BLOCAGE D'ENTRÉE LEVÉ (2026-10-28)
Le Guide v2 est fourni (PDF uploadé par le propriétaire) et recopié, dans ses
sections normatives, dans `docs/GUIDE-EXECUTION.md` (extrait vérifié). Les
éléments auparavant BLOQUÉ-ENTRÉE sont **débloqués** :
- **K4** format de blocs = §6 du Guide (voir docs/GUIDE-EXECUTION.md §Section 6).
- **K6/K15** barème = §5 + schéma question §8 (docs/GUIDE-EXECUTION.md).
- **K10** scénarios d'intrusion = §9.B (11 points).
- **K14** moteur « flèche » = §4.5. Références visuelles = images uploadées
  (parité pixel non affirmable sans rendu navigateur, règle 3/0.2).
- **K18** dépend de K4 (débloqué).

## État par élément
| Réf | État | Preuve | Rapport |
|---|---|---|---|
| K1 | **FAIT** | `test/k1.test.js` 6 cas, suite verte | RAPPORT_K1.md || K2 | **FAIT** | `test/k2.test.js` 7 cas (échoue-avant/passe-après), suite 20/0 | RAPPORT_K2.md |
| K3 | **FAIT** | `test/k3.test.js` 6 cas ; rouge→vert prouvé (K3a/b/c échouent sur l'état AVANT reconstitué), suite 21/0 | RAPPORT_K3.md |
| K4 | à faire (débloqué) | — | — |
| K5 | à faire (exécutable*) | — | — |
| K6 | à faire (débloqué) | — | — |
| K7 | **FAIT** | `test/k7.test.js` 6 cas ; rouge→vert prouvé (K7a échoue AVANT), suite 22/0 | RAPPORT_K7.md |
| K8 | **FAIT** | `test/k8.test.js` 5 cas ; rouge→vert prouvé (maintenance.js retiré ⇒ MODULE_NOT_FOUND avant), suite 23/0 | RAPPORT_K8.md |
| K9 | **FAIT** | `test/k9.test.js` 6 cas ; rouge→vert prouvé (bloc K9 retiré ⇒ 6 fail avant), suite 24/0 | RAPPORT_K9.md |
| K1ter | **FAIT** | `test/k1ter.test.js` 9 cas jsdom ; rouge→vert prouvé (K1ter-a/b/c échouent AVANT), suite 25/0 | RAPPORT_K1ter.md |
| K19 | **FAIT** | `test/k19.test.js` 7 cas (3 purs catalogue + 4 jsdom) ; list_matieres lit catalogue.json, `info` bientôt non cochable ; suite 26/0 | RAPPORT_K19.md |
| K20 | **FAIT** | `test/k20.test.js` 3 cas jsdom ; bandeau effacé au succès/début de rafraîchir + console rechargée après vérif ; `k1ter-i` rendu robuste ; suite 27/0 | RAPPORT_K20.md |
| K21 | **FAIT** | `test/k21.test.js` 8 cas jsdom (X6/X7) ; numéro obligatoire (≥8 chiffres, sinon pas d'approuver_nm), #g-code supprimé (un seul code/membre), quota « non appliqué », bouton d'essai → accorder_essai ; suite 28/0 | RAPPORT_K21.md |
| K22 | **FAIT** | `test/k22.test.js` 12 cas jsdom (X3/X4/X5/X8/X9/X10) ; pages publiques bleu nuit fixe sans sélecteur/script de thème, « Essayer »→demande.html?type=essai (case essai cochée), « Lien perdu ? » + écran de succès copiable (lien lecture seule/Copier/Ouvrir/favoris), decision.html liste les matières, vouvoiement, numéro +229 obligatoire ; suite 30/0 | RAPPORT_K22.md |
| K10 | à faire (débloqué, §9.B) | — | — |
| K11 | à faire (jsdom requis) | — | — |
| K12 | à faire (exécutable*) | — | — |
| K13 | à faire (exécutable*) | — | — |
| K14 | à faire (débloqué ; finition non jugeable sans rendu) | — | — |
| K15 | à faire (débloqué via K6) | — | — |
| K16 | à faire (dépend K2/K3/K7/K8) | — | — |
| K17 | **FAIT** (réintégré) | `test/k17.test.js` ; couleurs en dur retirées, `themes.css`/`base.css` | RAPPORT (base K21-K17) |
| K23 | **FAIT** | `test/k17.test.js` renforcé (X11) ; 3 couleurs corrigées (clair/sepia/gris sous AA sur `--masque` : 4.42/4.32/4.28 → 4.72/4.74/4.70), scan JS hors vendor (12 fichiers), regex anti-entité `&#…`, +6 paires de contraste ; rouge→vert prouvé ; suite 30/0 | RAPPORT_K23.md |
| K18 | à faire (dépend K4) | — | — |

## Prochain (ordre réel conseillé, PLAN-EXECUTION §2)
K3 -> K7 -> K8 -> K9 -> K10 (serveur, `node --test`) ; puis K4/K6 (contenu+éval) ;
puis installer jsdom et faire K11 -> K17 -> K12/K13/K16 ; puis K14/K15 ; puis K18.
Archive de bloc serveur à produire après K9/K10.

## En cours
- K23 terminé (X11, renforcement de K17). `themes.css` : 3 couleurs sous AA
  corrigées (clair `--succes` #1b7a3d→#1a753b, sepia `--accent` #9a4f12→#914a11,
  gris `--succes` #1f6f3a→#1d6837 ; ratios sur `--masque` 4.42/4.32/4.28 →
  4.72/4.74/4.70). `test/k17.test.js` : scan des `assets/*.js` hors vendor
  (12 fichiers), regex à lookbehind `(?<![&\w])` ignorant les entités `&#…`,
  +6 paires de contraste (`--accent` sur fond/surface/masque ; erreur/succès/
  texte-doux sur masque). Rouge→vert prouvé ; suite verte 30/30, 0 fail.
  Prochain (ordre SPECS §3) : **K11** (§2.1 lecteur de cours, flèches), puis
  K10, K4, K5, K6, K12→K16, K18, RAPPORT_FINAL.
