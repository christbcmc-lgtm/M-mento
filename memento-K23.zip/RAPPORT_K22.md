# RAPPORT_K22 — Pages publiques honnêtes et cohérentes (X3, X4, X5, X8, X9, X10)

> Format : (a) fait · (b) preuves · (c) reste · (d) risques · (e) gestes 📱
> Étiquettes : [fait-vérifié] prouvé par un test exécuté · [non-vérifié] · [hypothèse]

---

## (a) Ce qui est fait

**X3 — Palette fixe « bleu nuit » sur les pages publiques.** [fait-vérifié]
Sur `index.html`, `acces.html`, `demande.html`, `essai.html`, `decision.html` :
- l'élément `<html>` porte `data-theme="bleu-nuit"` en dur (palette imposée,
  aucun effet du thème enregistré du visiteur) ;
- le `<select class="theme">` a été retiré de l'en-tête ;
- les scripts de thème (`assets/js/theme-boot.js` et `assets/app-theme.js`) ne
  sont plus chargés sur ces pages (ils restent pour les pages membre) ;
- l'accueil ne vante plus « ✔ 8 thèmes d'affichage » (badge remplacé par
  « Thèmes de lecture dans votre espace », où le choix existe réellement).

**X4 — « Essayer gratuitement » mène au bon endroit.** [fait-vérifié]
- Le bouton de l'accueil pointe désormais vers `demande.html?type=essai`
  (plus vers `essai.html`, qui sans invitation menait à une page d'erreur).
- `demande.js` lit `?type=essai` et **présélectionne** la case « Essai gratuit ».

**X5 — `acces.html` : « Lien perdu ? » et écran de succès copiable.** [fait-vérifié]
- Un lien « Lien perdu ? » ouvre un petit formulaire de récupération (email +
  numéro) qui appelle `/api/public?a=code-reset` (réponse neutre affichée).
- L'écran de succès d'activation affiche le **lien personnel en lecture seule**,
  un bouton **Copier** (presse-papier + repli `execCommand`), un bouton
  **Ouvrir mon espace** (href = lien) et une **phrase invitant à l'ajouter aux
  favoris**.

**X8 — `decision.html` affiche les matières demandées.** [fait-vérifié]
- La fiche de décision ajoute une ligne « Matières demandées » ; `decision.js`
  mappe les identifiants reçus (`demande.matieres`) vers leurs titres lisibles
  via le catalogue (ex. `thermo` → « Thermodynamique »). Le serveur renvoyait
  déjà `matieres` dans `decisionGet` ; aucune modification serveur nécessaire.

**X9 — Vouvoiement partout.** [fait-vérifié]
- Accueil : « Tes cours, bien rangés » → « Vos cours, bien rangés » ; « Ce que tu
  trouves » → « Ce que vous trouvez » ; « Teste ta compréhension et repère » →
  « Testez votre compréhension et repérez ».
- `acces.html` (« Comment ça marche ») : « Envoie » → « Envoyez », « tu reçois » →
  « vous recevez », « Tu obtiens ton lien… ton espace » → « Vous obtenez votre
  lien… votre espace ».
- Contrôle : aucune occurrence de tutoiement ne subsiste dans les 5 pages.

**X10 — `demande.html` : numéro international obligatoire.** [fait-vérifié]
- Placeholder `06 12 34 56 78` → `+229 01 23 45 67 89` (format Bénin), champ
  marqué `required` et libellé complété par « (obligatoire) ». La validation
  JS « numéro requis » existait déjà dans `demande.js`.

## (b) Preuves (tests jsdom qui EXÉCUTENT le code de page)

`test/k22.test.js` — 12 cas, tous verts :

| Cas | Ce qu'il prouve |
|---|---|
| K22a | `data-theme="bleu-nuit"` sur `<html>` des 5 pages publiques |
| K22b | plus aucun `select.theme` sur les 5 pages |
| K22c | plus de `theme-boot.js` ni `app-theme.js` chargés sur les 5 pages |
| K22d | l'accueil ne contient plus « 8 thèmes » |
| K22e | « Essayer gratuitement » → `demande.html?type=essai` (plus `essai.html`) |
| K22f | (JS exécuté) `?type=essai` coche la case « Essai gratuit » |
| K22g | `#d-num` est `required`, placeholder `+229`, libellé « obligatoire » |
| K22h | (JS exécuté) « Lien perdu ? » révèle le formulaire de récupération |
| K22i | (JS exécuté) le formulaire appelle `code-reset` avec email + numéro |
| K22j | (JS exécuté) écran de succès : lien en lecture seule rempli, bouton Ouvrir pointant dessus, Copier présent, phrase « favoris » |
| K22k | (JS exécuté) `decision.html` affiche « Thermodynamique, Probabilités… » |
| K22l | aucun tutoiement restant sur les 5 pages |

**Suite complète** : `node --test` → **`# tests 30 / # pass 30 / # fail 0`**
(30 unités = 29 fichiers `*.test.js` + le helper `fake-db.js`).
Rappel d'environnement : sous **Node 16.20.2**, `# tests` compte les FICHIERS,
pas les `test()` ; ce n'est pas une régression (le « 154 » de référence était un
artefact de version). 0 fail prouve la suite verte.

## (c) Ce qui reste
- **K23** (X11) : renforcer `k17.test.js`.
- Puis K11, K10, K4, K5, K6, K12→K16, K18.

## (d) Risques / limites
- [hypothèse] L'action serveur `code-reset` attend bien `{ email, numero }` et
  renvoie un message neutre ; confirmé par lecture d'`api/public.js` (fonction
  `codeReset`), non rejoué bout-en-bout ici (test d'interface seulement).
- [non-vérifié] Rendu visuel exact (contraste, placement) non jugeable sans
  navigateur ; les pages utilisent les variables de thème, aucune couleur en dur
  ajoutée (K17 reste vert).
- `essai.html` est conservée : elle sert les aperçus sur **invitation** ; seul le
  lien d'accueil a changé de cible.
- Aucun secret, aucune dépendance ajoutée, `firestore.rules` inchangé.

## (e) Gestes 📱
1. Ouvrir l'accueil : il reste en bleu nuit, sans menu de thème ; le badge ne
   parle plus de « 8 thèmes ».
2. Toucher « Essayer gratuitement » → la page de demande s'ouvre avec « Essai
   gratuit » déjà coché.
3. Sur la page d'accès, toucher « Lien perdu ? » → un petit formulaire email +
   numéro apparaît ; après activation, le lien personnel s'affiche avec « Copier »,
   « Ouvrir mon espace » et une invitation à l'ajouter aux favoris.
4. Sur un lien de décision, les matières demandées sont listées en toutes lettres.
