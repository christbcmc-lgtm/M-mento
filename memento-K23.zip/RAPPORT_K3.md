# RAPPORT_K3 — Voie d'essai gratuit UNIFIÉE

> Reporting tagué : **[vérifié]** = constaté par exécution/lecture du code ;
> **[non vérifié]** = non testé ici ; **[hypothèse]** = choix de conception.
> Aucun secret, aucune clé, aucun jeton réel n'est reproduit dans ce document.

## 1. Objet

Il existait **deux** voies pour démarrer un essai gratuit côté admin :

1. `accorder_essai` → `essaisLib.accorderEssai` : crée un enregistrement
   `essais/{hashEmail}` (un email = un essai), pose `dureeMin`, `utiliseLe:0`,
   envoie un lien `/essai?i=<jeton essai_lien>`, filigrane = email.
2. `inviter_essai` → `token.signInviteEssai(7)` : fabriquait un jeton
   `t:'invite_essai'` et un lien `/essai.html?i=…` **sans** enregistrement
   `essais/{hash}`, **sans** unicité par email, **sans** filigrane ni compteur
   de temps serveur.

La voie (2) est un doublon non maîtrisé (pas de `essais/{hash}`, donc ni
unicité, ni chrono serveur, ni filigrane, ni passage par `list_essais` /
`supprimer_essai`). **K3 retire la voie (2)** : il ne reste qu'**une seule voie
d'octroi**, `accorder_essai`. **[vérifié]**

## 2. Modifications (noms de fichiers/champs exacts)

- **`api/_lib/token.js`** : fonction `signInviteEssai` **supprimée** et retirée
  de `module.exports` (remplacée par un commentaire de traçabilité K3). Plus
  aucun `jwt.sign({ t: 'invite_essai' }, …)`. **[vérifié]**
- **`api/admin.js`** : import `const { signInviteEssai } = require('./_lib/token')`
  **supprimé**. La branche `action === 'inviter_essai'` est conservée en
  **pierre tombale** : elle répond désormais
  `410 { ok:false, erreur:'Action retirée : utilisez « accorder un essai ».' }`
  au lieu de `200 { ok:true, lien }`. **[vérifié]**
  - **[hypothèse]** choix de la pierre tombale 410 plutôt que la suppression
    totale de la branche : un ancien appelant reçoit un message explicite
    (« action retirée ») au lieu du générique `400 Action inconnue`. La
    substance (mint de jeton + lien `?i=` sans enregistrement) est bien
    supprimée ; l'action ne fait plus rien de fonctionnel.
- **`public/assets/admin-client.js`** (ligne ~253, fonction `inviterEssai`) :
  l'appel `appel('inviter_essai', { email })` devient
  `appel('accorder_essai', { email })` ; message de succès mis à jour en
  « Essai accordé ✔ (lien envoyé par email) ». `accorderEssai` ne renvoie pas
  de `lien` (il est envoyé par email), donc le bloc d'affichage `#e-lien` reste
  inerte — comportement volontaire. **[vérifié]**
- **`test/h0.test.js`** : liste `ATTENDU.admin` remise à jour sur le code réel —
  ajout de `vider_appareils`, `prolonger`, `suspendre`, `reactiver`,
  `supprimer_membre` (actions K2) ; `inviter_essai` **conservée** dans la liste
  car la branche (pierre tombale) existe toujours dans `admin.js`. **[vérifié]**
- **`docs/CONTRAT-API.md`** : `inviter_essai` documenté comme **retirée (410)** ;
  `accorder_essai` détaillé (`{ email, nom?, prenom?, dureeMin? }` →
  `{ ok:true, hash, lien? }`, 409 doublon) ; ajout du tableau **K2** (cycle de
  vie membre : `prolonger` / `suspendre` (+`tokenVersion++`) / `reactiver` /
  `supprimer_membre` cascade + libération verrou email D21). **[vérifié]**

> **Non modifié** (volontaire) : `api/_lib/essais.js` déjà correct
> (`accorderEssai` renvoie 409 si `essais/{hash}` existe ; `ouvrirEssai`
> n'accepte que `t:'essai_lien'` ; `utiliseLe` fixé à la 1re ouverture, jamais
> remis à zéro). K3 n'y touche pas. **[vérifié]**

## 3. Test — `test/k3.test.js` (6 cas)

Fingerprint du retrait (rouge AVANT, vert APRÈS) :
- **K3a** `token.signInviteEssai` est `undefined` ET `token.js` ne contient plus
  `t: 'invite_essai'`.
- **K3b** `admin.js` ne contient plus `signInviteEssai` ni de lien `?i=`, et la
  branche `inviter_essai` répond `410`.
- **K3c** `admin-client.js` appelle `accorder_essai` et non plus `inviter_essai`.

Garanties de comportement de la voie unique (vertes) :
- **K3d** `accorder_essai` crée `essais/{hash}` ; **doublon même email → 409** ;
  après `supprimer_essai`, un **re-octroi** du même email réussit.
- **K3e** `ouvrirEssai` **rejette (410)** un jeton forgé `t:'invite_essai'`
  (seul `essai_lien` est accepté), et un `essai_lien` sans enregistrement → 410.
- **K3f** ouvrir deux fois ne bouge pas `utiliseLe` et le temps restant ne
  remonte jamais (actualisation ≠ remise à zéro du chrono).

## 4. Preuve rouge→vert **[vérifié]**

État AVANT reconstitué (signInviteEssai + mint + lien `?i=` + front
`inviter_essai` restaurés dans des copies de travail, puis revert) :

```
=== k3 sur ETAT AVANT (doit ECHOUER) ===
not ok 1 - K3a : token.signInviteEssai retiré + plus de mint t:'invite_essai'
not ok 2 - K3b : admin.js inviter_essai -> 410, sans signInviteEssai ni lien ?i=
not ok 3 - K3c : admin-client appelle accorder_essai (plus inviter_essai)
# pass 3  # fail 3
=== k3 sur ETAT APRES (doit PASSER) ===
# pass 1  # fail 0
```

K3d/e/f passent AVANT comme APRÈS : ils documentent que la voie unique couvre
déjà tout le besoin (c'est pourquoi la voie (2) était un doublon superflu).

## 5. Suite complète **[vérifié]**

`node --test` : **21 fichiers, 21 pass, 0 fail** (dont `h0` recalé sur le code
réel, `k1`, `k2`, `k3`).

## 6. Hors périmètre / limites

- **[non vérifié]** Comportement HTTP réel de `admin.js?a=inviter_essai` (410) :
  non testé via le handler car `admin.js` dépend de `firebase-admin`
  (`verifyIdToken`) sans point d'injection ; le 410 est vérifié au niveau
  **source** (K3b). Aucun test ne mocke Firebase (interdit d'ajouter des deps
  serveur).
- Aucun `push` GitHub. Aucune nouvelle dépendance. Aucun secret écrit.
