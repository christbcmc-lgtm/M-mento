# RAPPORT K8 — Maintenance admin : journal d'audit, stockage, purge ciblée

> Référentiel : Guide v2 §D21 (page Stockage / purge) et §D22 (stats agrégées,
> pas de balayage au tableau de bord). Reporting tagué : **fait vérifié** /
> **non vérifié** / **hypothèse**. Noms de fichiers/champs exacts. ZÉRO secret.

## Périmètre livré

Trois actions admin ajoutées, toutes portées par un nouveau module **pur et
testable** `api/_lib/maintenance.js` (base injectée), câblé dans `api/admin.js` :

| Action | Type | Rôle |
|---|---|---|
| `list_journal` | lecture seule | Journal d'audit, du plus récent au plus ancien, borné (`max` 1–500, défaut 100). |
| `stockage` | lecture seule | Rapport de stockage : `{demandes, demandesRejetees, membres, essais, journal}`. |
| `purger` | écriture (destructive **ciblée**) | Purge une `cible` de la liste blanche uniquement ; renvoie `{ok, cible, supprime}`. |

## Décisions de conception (et ce qui est vérifié vs hypothèse)

1. **Purge jamais implicite — moindre privilège.** (*fait vérifié* : code)
   `purger(db, cible)` refuse toute cible hors liste blanche
   `CIBLES_PURGE = ['journal', 'demandes_rejetees']` avec
   `erreur(400, 'Cible de purge inconnue.')` et **ne supprime rien** dans ce cas
   (test K8e). La liste blanche ne contient que des données **transitoires** :
   le journal d'audit et les demandes de statut `rejetee`. Les `membres`,
   `essais`, `messages`, `resultats`/`evals` ne sont **jamais** purgeables par
   cette voie. Rationnel : §D21 demande « purger » sans énumérer les données
   exactes ⇒ je refuse d'inventer une purge en cascade destructrice (règle 7) et
   j'expose une purge **explicitement choisie par l'admin**. (*hypothèse* : le
   choix des deux cibles transitoires ; à étendre si le propriétaire spécifie
   d'autres cibles.)

2. **La trace de purge survit à la purge du journal.** (*fait vérifié* : test K8c)
   `purger` supprime d'abord, puis écrit l'entrée d'audit `action:'purge'` via
   `journal(...)`. Après `purger(db,'journal')`, le journal contient exactement
   **1** entrée (la purge elle-même), pas zéro.

3. **`journal()` exporté et doté d'un champ `type`.** (*fait vérifié* : code)
   `api/_lib/inscription.js` exporte désormais `journal`, réutilisé par
   `maintenance.js` (pas de duplication). Signature étendue
   `journal(db, qui, action, cible, type)` avec `type` par défaut `'info'`
   (non-cassant : les appels existants à 3 arguments restent valides). Ce champ
   `type` prépare l'entrée de **type alerte** de K9 (§9.C). (*non vérifié* : K9
   lui-même, non encore implémenté.)

4. **Pas de balayage au tableau de bord ; comptage borné toleré en maintenance.**
   (*hypothèse* assumée, documentée) §D22 interdit le balayage pour `stats`
   (inchangé : `stats` lit toujours le compteur global). `stockage` est une page
   de maintenance occasionnelle, pas le tableau de bord sondé en continu ; un
   comptage borné par `get()` y est donc accepté. Commenté dans le code.

5. **Compatibilité base réelle / base de test.** (*fait vérifié* : code + tests)
   `maintenance.js` n'utilise ni `orderBy` ni `limit` ni `.where` (absents de
   `test/fake-db.js`) : il lit via `get()` puis trie/découpe en mémoire. Compatible
   avec Firestore réel et avec la base de test.

## Preuve rouge → vert (par élément)

- **Rouge (avant)** : `mv api/_lib/maintenance.js` hors de l'arborescence puis
  `node --test test/k8.test.js` ⇒ `MODULE_NOT_FOUND` (le module n'existe pas),
  **# fail 1**. (*fait vérifié*, sortie capturée.)
- **Vert (après)** : module restauré ⇒ `test/k8.test.js` **5 cas pass**.
- **Suite complète** : `node --test` ⇒ **23 fichiers, 23 pass, 0 fail**.
- **Syntaxe** : `node -c` OK sur `admin.js`, `maintenance.js`, `inscription.js`.

### Cas de test (`test/k8.test.js`)
1. `K8a` tri décroissant par `le` + bornage `max`.
2. `K8b` compteurs de stockage (dont `demandesRejetees`).
3. `K8c` purge `journal` : vide + laisse sa propre trace.
4. `K8d` purge `demandes_rejetees` : n'efface que les `rejetee`, journalisée.
5. `K8e` cible inconnue ⇒ `400`, **aucune** suppression.

## Fichiers touchés
- `api/_lib/maintenance.js` — **nouveau** (listerJournal, rapportStockage, purger, CIBLES_PURGE).
- `api/_lib/inscription.js` — `journal` exporté + champ `type` (défaut `'info'`).
- `api/admin.js` — require `maintLib` + actions `list_journal` / `stockage` / `purger`.
- `docs/CONTRAT-API.md` — section « K8 — maintenance admin ».
- `test/h0.test.js` — `ATTENDU.admin` + `list_journal`, `stockage`, `purger`.
- `test/k8.test.js` — **nouveau**, 5 cas.
- `PROGRESS.md` — K8 FAIT, suite 24/0.

## Limites connues / non vérifié
- **Interface admin HTML** (bouton « Stockage » / affichage du journal dans
  `admin.html` / `admin-client.js`) : **non traitée dans K8** (K8 = couche
  serveur/lib, testable sans navigateur). À câbler côté interface lors du bloc
  front (jsdom), si le Guide l'exige. (*fait non vérifié*.)
- `admin.js` reste non testable en HTTP (dépend de `firebase-admin`, pas
  d'injection) : les asserts portent sur `maintenance.js` au niveau lib.
- Cibles de purge : seules deux cibles transitoires sont permises ; toute autre
  politique de rétention doit être spécifiée par le propriétaire avant élargissement.
