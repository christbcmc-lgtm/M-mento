# RAPPORT K9 — Réponse aux abus (§9.C)

> Reporting tagué : **fait vérifié** / **non vérifié** / **hypothèse**. Noms exacts. ZÉRO secret.

## Périmètre livré (§9.C)
Seuil **10 refus d'authentification en 5 min** depuis une même adresse → **429**
avec le **message EXACT** « Activité inhabituelle détectée. Cette adresse est
temporairement bloquée et l'administrateur en est informé. », **une** entrée
`journal` de **type `alerte`**, et un **compteur visible au tableau de bord**
(`compteurs/global.alertesAbus`, exposé par `stats`). Aucune contre-mesure offensive.

## Implémentation (*fait vérifié* : code + tests)
- `api/_lib/limites.js` : `MSG_ABUS`, `MAX_REFUS_AUTH=10`, `FENETRE_ABUS_SEC=300`,
  + `gardeAbus(db, ip)` (jette 429 MSG_ABUS si l'adresse est déjà bloquée dans la
  fenêtre, **sans** incrémenter) et `signalerRefusAuth(db, ip, deps?)` (incrémente
  le compteur d'abus par IP hachée dans la collection `abus`, fenêtre glissante ;
  au franchissement EXACT du seuil, écrit **une** alerte journal + incrémente le
  compteur ; jette 429 MSG_ABUS dès n>=10). `journal`/`incr` injectables (tests),
  sinon repris de `inscription.js`.
- `api/auth.js` branche `code` : `gardeAbus` en entrée, `signalerRefusAuth` sur le
  refus « Code incorrect. ». Le routeur honore `e.status` → 429 propagé.
- `api/admin.js` `stats` : ajoute `alertesAbus` (lu sur `compteurs/global`).
- Collection `abus` distincte de `limites` (doc par IP hachée : `{n,debut,alerteEmise}`).

## Preuve rouge → vert
- **Rouge** : `limites.js` privé du bloc K9 → `node --test test/k9.test.js` = **6 fail**.
- **Vert** : bloc restauré → `test/k9.test.js` **6 cas pass** ; suite **24 fichiers, 24 pass, 0 fail** ; `node -c` OK (auth/admin/limites).

### Cas (`test/k9.test.js`)
1. message/seuil/fenêtre figés (égalité EXACTE du message). 2. 9 refus = pas de
blocage ni alerte. 3. 10e refus = 429 MSG_EXACT + 1 alerte + compteur=1. 4.
`gardeAbus` bloque ensuite sans incrémenter. 5. fenêtre écoulée = remise à zéro.
6. alerte écrite **une seule fois** par blocage.

## Limites / non vérifié
- *fait non vérifié* : `auth.js` non testable en HTTP (dépend firebase-admin) ; le
  câblage est vérifié au niveau source, le comportement 429 est prouvé au niveau lib.
- *hypothèse* : le câblage couvre le point de refus le plus net (mauvais `code`).
  Le §9.C évoque aussi « appels répétés de contenu sans session » : `gardeAbus`/
  `signalerRefusAuth` sont prêts à être branchés ailleurs (contenu/eval) si requis.
- Affichage du compteur `alertesAbus` dans l'interface admin (`admin.html`) : **non
  traité** ici (couche serveur) ; `stats` l'expose, à afficher au bloc front.
