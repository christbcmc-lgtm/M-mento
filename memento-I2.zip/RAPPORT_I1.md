# RAPPORT I1 — Vider les appareils d'un membre (action admin + régénération de lien)

> Protocole : un seul élément (I1), un test qui échoue AVANT / passe APRÈS, un rapport,
> un zip, puis STOP. Aucune renumérotation. Aucun push GitHub. Aucun secret dans le
> dépôt, le rapport ou le chat. Réponses taguées « fait vérifié / non vérifié / hypothèse ».

## Objet
Implémenter la fonction « vider les appareils » prévue par le guide : **D5** (« L'admin peut
vider la liste ») et la fiche membre §4.3 (« prolonger, suspendre, régénérer le lien,
**vider les appareils**, supprimer »). Deux points :
1. une action admin `vider_appareils { membreId }` qui efface toute la sous-collection
   `membres/{id}/appareils` et journalise l'action ;
2. `regenerer_lien` ferme désormais aussi les appareils **par défaut** (le lien précédent
   étant révoqué, les sessions ouvertes n'ont plus lieu d'être), avec une option
   `viderAppareils:false` pour conserver la liste.

## Périmètre (inchangé pour le reste)
- Aucun changement de contenu pédagogique ni d'apparence (aucun fichier `public/` ni
  `contenu/` touché).
- Aucune renumérotation.
- Aucun push GitHub.

## (a) Ce qui est fait — fait vérifié
- **`api/_lib/session.js`** : nouvelle fonction `viderAppareils(db, membreId)` — liste la
  sous-collection `membres/{id}/appareils`, supprime chaque document, renvoie le nombre
  supprimé. Idempotente (0 sur liste vide). Export ajouté.
- **`api/_lib/inscription.js`** :
  - nouvelle fonction `viderAppareilsMembre(db, params)` : `400` si `membreId` absent,
    `404` si le membre est introuvable, sinon vide les appareils via `sess.viderAppareils`,
    écrit une entrée `journal` (`qui='admin'`, `action='vider_appareils'`, `cible=membreId`),
    renvoie `{ ok:true, appareilsSupprimes }`. Export ajouté.
  - `regenererLien` : après l'écriture réussie de `tokenVersion` (ordre H1 préservé : email
    AVANT écriture, `502` si l'envoi échoue), vide les appareils **par défaut** ;
    `params.viderAppareils === false` désactive ce vidage. Renvoie désormais
    `{ ok:true, appareilsSupprimes }`.
- **`api/admin.js`** : nouvelle action POST `vider_appareils` → `inscLib.viderAppareilsMembre`
  (réservée à l'admin par `estAdmin`, en-tête `X-Requested-With: mh` déjà exigé en amont
  comme pour toute mutation admin).
- **`docs/CONTRAT-API.md`** : ligne `vider_appareils` ajoutée à la table `admin` ;
  note `regenerer_lien` mise à jour (vidage par défaut + option, sortie `appareilsSupprimes`).

## (b) Preuves — commandes et résultats réels
Fichier de test ajouté : `test/i1.test.js` (7 cas). Les fonctions sont testées
directement (lib injectée), comme pour H1, avec `test/fake-db.js` (Firestore en mémoire).

### AVANT la correction (fonctions absentes / vidage non branché)
```
$ node --test test/i1.test.js
...
# tests 7
# pass 1
# fail 6
```
Seul **I1e** passait déjà (un échec d'email abandonne tout, comportement H1 préexistant).
Les 6 autres échouaient : `sess.viderAppareils` et `insc.viderAppareilsMembre`
étaient absents, et `regenererLien` ne vidait pas les appareils.

### APRÈS la correction
```
$ node --test test/i1.test.js
# tests 7  # pass 7  # fail 0   (I1a, I1b, I1b', I1b'', I1c, I1d, I1e)

$ node --test            # suite complète
# tests 16  # pass 16  # fail 0  (aucune régression : h0, h1, h2, f*, g, phase2..7)
```

Cas couverts :
- **I1a** `sess.viderAppareils` supprime 3 appareils, renvoie 3, sous-collection vide,
  rappel idempotent = 0.
- **I1b** `viderAppareilsMembre` vide et écrit l'entrée journal `vider_appareils`.
- **I1b'** membre inconnu → `404`, aucune entrée journal.
- **I1b''** `membreId` absent → `400`.
- **I1c** `regenererLien` vide par défaut (`appareilsSupprimes=2`, 0 restant) et incrémente
  `tokenVersion` à 1.
- **I1d** `regenererLien { viderAppareils:false }` conserve les 2 appareils ; `tokenVersion`
  tout de même incrémentée.
- **I1e** échec d'email → `502`, appareils conservés, `tokenVersion` inchangée.

## (c) Ce qui reste
- Lot I suivant selon l'ordre convenu : **I2** (normalisation email gmail/googlemail —
  à vérifier dans `emails.normaliser`), puis I3, I4, I5, H3, H4. Non entamés (STOP ici).
- Côté interface (`public/admin.html`) : le bouton « Vider les appareils » de la fiche
  membre n'est **pas** branché dans ce lot (I1 est strictement côté serveur/API).
  À relier dans le lot interface, en appelant `POST /api/admin { action:'vider_appareils',
  membreId }` avec l'en-tête `X-Requested-With: mh`. — **non vérifié** (hors périmètre I1).

## (d) Risques
- `viderAppareils` effectue une suppression document par document (pas de suppression
  récursive atomique). En production Firestore réel, c'est N écritures ; le volume est
  borné par `maxAppareils` (1 ou 2), donc négligeable. — **hypothèse** (cohérente avec D5).
- Après vidage, le membre doit rouvrir une session via son lien personnel. Avec
  `regenerer_lien`, c'est attendu (nouveau lien envoyé). Avec `vider_appareils` seul,
  le membre réutilise son lien courant (toujours valide) — comportement voulu.
- `fake-db.js` ne reproduit pas tout Firestore (pas d'`orderBy` sur sous-collection) ;
  `viderAppareils` n'utilise que `collection().get()`/`doc().delete()`, couverts par le
  faux. Validation navigateur/téléphone requise ci-dessous. — **fait vérifié** (code lu).

## (e) Gestes à faire par le propriétaire (jsdom ≠ navigateur — à tester sur téléphone)
Ces points touchent le vrai Firestore / la vraie session : ils ne sont pas prouvables en
local. À vérifier une fois branché en interface (ou via un appel direct à l'API admin
authentifié) :
1. Avec un membre connecté sur un téléphone, déclencher `vider_appareils` pour ce membre,
   puis recharger « Mon espace » sur le téléphone : l'accès doit redemander une nouvelle
   poignée de main (le cookie pointe vers un appareil qui n'existe plus) — et dans la
   limite `maxAppareils`, la réouverture doit réussir.
2. Déclencher `regenerer_lien` : vérifier que l'ancien lien `?t=` ne fonctionne plus,
   que le nouveau lien reçu par email fonctionne, et que la liste des appareils est vide.
3. Vérifier dans la console Firebase que la sous-collection `membres/{id}/appareils` est
   bien vidée et qu'une entrée `journal` `vider_appareils` / `regenerer_lien` a été écrite.

## Livrable
`outputs/memento-I1.zip` (arborescence du projet, sans `node_modules`).

## STOP
I1 terminé et livré. En attente du « feu vert » avant d'entamer I2.
Aucun push GitHub effectué. Aucun secret dans le dépôt ni dans ce rapport.
