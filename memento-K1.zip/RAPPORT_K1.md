# RAPPORT K1 — estAdmin exige email_verified === true (D12 / M1)

> Protocole : un élément, un test qui échoue AVANT / passe APRÈS, un rapport,
> PROGRESS.md à jour, suite verte. Aucun push GitHub. Aucun secret. Reporting
> tagué « fait vérifié / fait non vérifié / hypothèse ».

## Objet
La garde admin (`estAdmin` dans `api/admin.js`) comparait l'email du jeton
Firebase à `ADMIN_EMAIL` **sans** vérifier `email_verified`. D12 (M1) impose que
l'accès admin exige un email **vérifié**. Sans cette vérification, un compte dont
l'adresse n'est pas confirmée mais égale à `ADMIN_EMAIL` pouvait être accepté.

## (a) Ce qui est fait — fait vérifié
- **`api/admin.js`** : extraction d'une garde PURE et testable
  `adminAutorise(dec, attendu)` qui exige, dans l'ordre : `dec` présent,
  `attendu` non vide, `dec.email_verified === true` (**nouveau, K1**), puis
  `dec.email` (minuscules) `=== attendu`.
- `estAdmin(req)` vérifie toujours le `Bearer`, décode via
  `auth().verifyIdToken`, puis délègue la décision à `adminAutorise`. Comportement
  réseau inchangé ; seule la règle d'autorisation est renforcée.
- `adminAutorise` exporté en auxiliaire (`module.exports.adminAutorise`) sans
  toucher au handler HTTP exporté par défaut.

## (b) Preuves — commandes et résultats réels
Fichier de test ajouté : `test/k1.test.js` (6 cas). Le test K1a prouve le trou
en comparant au comportement de l'ANCIENNE garde (email seul).

```
$ node --check api/admin.js
SYNTAXE admin.js OK

$ node --test test/k1.test.js        # 6 sous-tests
# pass 1  # fail 0   (fichier OK)

$ node --test                        # suite complète
# tests 19  # pass 19  # fail 0
```

**Échoue AVANT / passe APRÈS** : K1a asserte à la fois
`adminAutorise({email:ADMIN, email_verified:false}) === false` (nouveau
comportement) ET `ancienneGarde(...) === true` (preuve que l'ancienne logique
l'aurait laissé passer). Avant l'ajout du test, `adminAutorise` n'existait pas
et `estAdmin` ne testait pas `email_verified` ; la règle K1 était donc violée.

Cas couverts :
- **K1a** jeton non vérifié (`email_verified:false`) → refusé (ancien = accepté).
- **K1b** `email_verified` absent → refusé.
- **K1c** vérifié + bon email → accepté.
- **K1d** vérifié mais email différent → refusé.
- **K1e** casse de l'email ignorée.
- **K1f** garde-fous (`dec` nul, `attendu` vide).

## (c) Ce qui reste
- Bloc 1 : K2–K10. Voir PLAN-EXECUTION.md et PROGRESS.md. **Plusieurs éléments
  sont BLOQUÉ-ENTRÉE** faute du Guide et des références (voir ci-dessous).

## (d) Risques
- **fait non vérifié** : le comportement réseau complet d'`estAdmin` (appel réel
  à `verifyIdToken`) n'est pas testé ici (nécessiterait un stub Firebase). La
  logique d'autorisation PURE l'est. — **hypothèse** : `verifyIdToken` renvoie
  bien un champ `email_verified` booléen (standard Firebase). À confirmer en
  service réel.
- Aucun changement destructeur, aucune donnée touchée.

## (e) Gestes propriétaire 📱 / console
1. Se connecter à la console admin avec le compte `ADMIN_EMAIL` **vérifié** →
   accès normal.
2. (Si possible) tester avec un compte dont l'email n'est pas vérifié → doit
   être refusé (403). En pratique, vérifier dans Firebase Auth que le compte
   admin a bien « Email vérifié » activé.

## ⚠ Signalement bloquant (annexe §0.2)
Les fichiers que l'annexe demande de lire « en entier » sont en partie **absents**
du dépôt (voir PLAN-EXECUTION.md §0 et PROGRESS.md) : `docs/GUIDE-EXECUTION.md`,
`docs/QUALITE-MATIERE.md` et tout `docs/reference/*`. La suite de la grande
partie dépend de ces entrées pour ne pas inventer de spécifications.

## Livrable
`outputs/memento-K1.zip` (arborescence du projet, **sans `node_modules`**).
