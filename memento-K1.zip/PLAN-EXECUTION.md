# PLAN-EXECUTION.md — Grande partie K1 → K18

> Écrit par l'IA avant exécution, conformément à QUALITE-MATIERE §8.
> Ordre, dépendances, risques. Point de vérité : le code réel + CONTRAT-API.md
> + DECISIONS.md + ce message du propriétaire (annexe QUALITÉ).
> Reporting tagué : « fait vérifié / fait non vérifié / hypothèse ».

## 0. ENTRÉES MANQUANTES (bloquant partiel — §0.2 de l'annexe)

L'annexe exige de lire « en entier » avant d'exécuter :
`docs/GUIDE-EXECUTION.md`, `docs/QUALITE-MATIERE.md`, `docs/CONTRAT-API.md`,
puis `docs/reference/*`. État réel du dépôt (extrait de memento-I4.zip) :

| Fichier attendu | État |
|---|---|
| `docs/CONTRAT-API.md` | **PRÉSENT** |
| `docs/GUIDE-EXECUTION.md` | **ABSENT** |
| `docs/QUALITE-MATIERE.md` | **ABSENT** (son contenu = le message du 25/10, pas un fichier) |
| `docs/reference/optique-page.png` | **ABSENT** |
| `docs/reference/memento-thermo.png` | **ABSENT** |
| `docs/reference/pastille-etapes.png` | **ABSENT** |
| `docs/reference/optique-index.html` | **ABSENT** |

> `GUIDE_CONFIGURATION.md` (racine) existe mais c'est le guide **Firebase/Vercel
> pour le propriétaire**, PAS le « Guide d'exécution strict v2 » technique.

Conséquences, par la règle 0.2 (« sans ces fichiers, l'IA ne peut pas juger la
qualité visuelle et doit le dire ») et la règle 7 (« ne pas inventer ») :

- **Je ne peux pas juger ni reproduire la fidélité visuelle à Optique** (K12–K17,
  §3) sans `docs/reference/*`. Je peux construire la **structure** spécifiée
  dans l'annexe, mais pas affirmer la parité de finition.
- **Je ne connais pas les formats exacts du Guide** référencés par : K4 (« format
  section 6 du Guide » pour les blocs de contenu), K6 (« barème / phase 5 du
  Guide »), K10 (« 9.B intrusion »), et le « moteur flèche 4.5 » pour la
  navigation par chapitre. Les inventer violerait la règle 7.

Tout élément dépendant de ces entrées est marqué **BLOQUÉ-ENTRÉE** ci-dessous.
Le reste (spécifié par le code existant + l'annexe) est **EXÉCUTABLE**.

## 1. Classement des éléments

### Bloc 1 — serveur
| Réf | État | Note |
|---|---|---|
| K1 estAdmin email_verified | **FAIT** | Spécifié (D12/M1). Livré. |
| K2 prolonger/suspendre/reactiver/supprimer_membre | EXÉCUTABLE | Cascade + libération verrou email + journal dérivables du code ; noms de statut à confirmer dans le code. |
| K3 une seule voie d'essai | EXÉCUTABLE* | Comportement décrit ; « recette du Guide » exacte à recouper (BLOQUÉ-ENTRÉE partiel). |
| K4 contenu par chapitre (format §6 Guide) | **BLOQUÉ-ENTRÉE** | Schéma de blocs inconnu ; test d'égalité impossible à cadrer. |
| K5 media/pdf/recherche/notes/theme | EXÉCUTABLE* | recherche (§3.10), notes (20000), theme (8) spécifiés ; contrat exact index à fixer. |
| K6 évaluation start/submit/historique/ratees | **BLOQUÉ-ENTRÉE** | « barème / phase 5 du Guide » inconnu (un barème /20 existe en code, à confirmer comme référence). |
| K7 ressources PDF (admin) | EXÉCUTABLE | Décrit dans l'annexe. |
| K8 admin stats/stockage/purge/journal | EXÉCUTABLE | Décrit. |
| K9 réponse aux abus (9.C) | EXÉCUTABLE* | Seuils donnés (10 refus/5 min → 429) ; message exact à fixer. |
| K10 intrusion 9.B + CSP + docs | **BLOQUÉ-ENTRÉE** partiel | Scénarios 9.B inconnus ; CSP/docs exécutables. |

### Bloc 2 — interface
| Réf | État | Note |
|---|---|---|
| K11 pastille retirée + flèches + Revenir(n) | EXÉCUTABLE | **Spécifié intégralement §2** (Q-D1–Q-D4). Besoin de jsdom (test §9.2). |
| K12 interface publique (accueil, Aide, succès connexion) | EXÉCUTABLE* | Structure spécifiée ; finition non jugeable sans références. |
| K13 Mon espace | EXÉCUTABLE* | idem. |
| K14 page matière qualité Optique | **BLOQUÉ-ENTRÉE** | Fidélité Optique non jugeable sans `docs/reference/*` ; moteur 4.5 inconnu. |
| K15 évaluation/révision (interface) | dépend de K6 | BLOQUÉ-ENTRÉE via K6. |
| K16 console admin complète | EXÉCUTABLE* | dépend de K2/K3/K7/K8. |
| K17 passe de qualité (contraste, 0 couleur en dur) | EXÉCUTABLE | Calcul sur variables de thème. |

### Bloc 3 — contenu
| K18 thermo (conversion + _/^ + mise en forme) | **BLOQUÉ-ENTRÉE** | dépend du format §6 (K4). Sauf la correction « texte brut » `_`/`^` (M12) qui est exécutable seule. |

## 2. Dépendances
- K15 ← K6 ; K16 ← K2,K3,K7,K8 ; K14 ← K4,K5,K11 ; K18 ← K4.
- Ordre conseillé réel : K1 → K2 → K3 → K7 → K8 → K9 → (K4,K6,K10 dès le Guide fourni)
  → K11 → K17 → K12/K13/K16 → (K14,K15 dès références+Guide) → K18.

## 3. Risques majeurs
- **Inventer les formats du Guide** (K4/K6) = livrable rejeté + reprise coûteuse. Mitigé : BLOQUÉ-ENTRÉE tant que le Guide n'est pas fourni.
- **Affirmer une parité visuelle Optique** non vérifiable (règle 0.2). Mitigé : construire la structure, déclarer l'absence de référence.
- **jsdom** requis pour les tests d'interface (§9.2) : dépendance de test seulement (pas une dépendance serveur ; règle 6 préservée). À installer avant K11.
- **Suppression en cascade** (K2) = action destructrice sur données → tests exhaustifs + confirmation côté console (K16). Aucune donnée réelle en prod (D15, à confirmer).

## 4. Garde-fous appliqués (§9)
Feu rouge = arrêt (suite `node --test` verte après chaque élément ; 2 échecs de
correction → BLOQUÉ dans PROGRESS.md). Un test échoue-avant/passe-après par
élément. Un RAPPORT_Kn.md par élément. PROGRESS.md à jour. Aucun push GitHub,
aucun jeton, aucun secret, rien hors périmètre, firestore.rules deny-all.
