# PROGRESS.md — point de reprise (grande partie K1→K18)

> Fichier de reprise unique (QUALITE-MATIERE §9.3). Une autre IA doit pouvoir
> continuer à partir de ce seul fichier. Mis à jour après chaque élément.
> Dernière mise à jour : 2026-10-28.

## Base de travail
- Dossier : extrait de `memento-I4.zip`.
- Suite de tests : `node --test` — **19 fichiers, 19 pass, 0 fail** (dont `k1.test.js`).
- `node_modules` installé (hors zip). jsdom **PAS encore installé** (requis pour tests interface K11+).

## ⚠ BLOQUÉ-ENTRÉE (en-tête de reprise)
Trois entrées obligatoires de l'annexe sont **absentes du dépôt** (voir
PLAN-EXECUTION.md §0). Tant qu'elles ne sont pas ajoutées par le propriétaire,
les éléments suivants ne peuvent PAS être faits sans inventer (règles 0.2 et 7) :
- **K4** (format de blocs « §6 du Guide ») — besoin : `docs/GUIDE-EXECUTION.md`.
- **K6 / K15** (barème + format « phase 5 du Guide ») — besoin : `docs/GUIDE-EXECUTION.md`.
- **K10** (scénarios 9.B) — besoin : `docs/GUIDE-EXECUTION.md`.
- **K14** (fidélité visuelle Optique + moteur flèche 4.5) — besoin : `docs/reference/*` + `docs/GUIDE-EXECUTION.md`.
- **K18** (conversion thermo) — dépend de K4.

Fichiers réclamés au propriétaire : `docs/GUIDE-EXECUTION.md`,
`docs/QUALITE-MATIERE.md`, `docs/reference/optique-page.png`,
`docs/reference/memento-thermo.png`, `docs/reference/pastille-etapes.png`,
`docs/reference/optique-index.html`.

## État par élément
| Réf | État | Preuve | Rapport |
|---|---|---|---|
| K1 | **FAIT** | `test/k1.test.js` 6 cas (échoue-avant/passe-après), suite verte | RAPPORT_K1.md |
| K2 | à faire (exécutable) | — | — |
| K3 | à faire (exécutable*) | — | — |
| K4 | **BLOQUÉ-ENTRÉE** | — | — |
| K5 | à faire (exécutable*) | — | — |
| K6 | **BLOQUÉ-ENTRÉE** | — | — |
| K7 | à faire (exécutable) | — | — |
| K8 | à faire (exécutable) | — | — |
| K9 | à faire (exécutable*) | — | — |
| K10 | **BLOQUÉ-ENTRÉE** partiel | — | — |
| K11 | à faire (exécutable ; jsdom requis) | — | — |
| K12 | à faire (exécutable*) | — | — |
| K13 | à faire (exécutable*) | — | — |
| K14 | **BLOQUÉ-ENTRÉE** | — | — |
| K15 | BLOQUÉ via K6 | — | — |
| K16 | à faire (dépend K2/K3/K7/K8) | — | — |
| K17 | à faire (exécutable) | — | — |
| K18 | **BLOQUÉ-ENTRÉE** (sauf _/^ M12) | — | — |

## Prochain
- Si Guide + références fournis : reprendre l'ordre de PLAN-EXECUTION §2.
- Sinon, sous accord « continuer sans le Guide » : enchaîner **K2 → K3 → K7 → K8 → K9 → K11 → K17** (éléments exécutables), en taguant toute hypothèse.

## En cours
- Rien (arrêt propre après K1 pour signaler les entrées manquantes, règle 0.2).
